// Hardened typed API client for the Hidden Grain read-only API.
// It validates every successful payload, preserves structured backend errors,
// enforces a timeout, supports conditional GET with ETag and never mocks data.

import { z } from "zod";

import {
  ApiContractError,
  ApiError,
  ApiNetworkError,
  ApiNotFoundError,
  ApiTimeoutError,
} from "./errors";
import {
  apiErrorEnvelopeSchema,
  graphResponseSchema,
  healthResponseSchema,
  objectDetailResponseSchema,
  objectsListResponseSchema,
} from "./schemas";
import type { ObjectsQueryParams } from "./types";

const RAW_BASE = (import.meta.env.VITE_HG_API_BASE ?? "").toString().trim();
const RAW_TIMEOUT = (import.meta.env.VITE_HG_REQUEST_TIMEOUT_MS ?? "10000").toString().trim();

function resolveBase(): string {
  if (!RAW_BASE) return "/api";
  return RAW_BASE.replace(/\/+$/, "");
}

function resolveTimeout(): number {
  const value = Number(RAW_TIMEOUT);
  return Number.isFinite(value) && value > 0 ? value : 10_000;
}

export const API_BASE = resolveBase();
export const API_REQUEST_TIMEOUT_MS = resolveTimeout();

const etagCache = new Map<string, { etag: string; value: unknown }>();

function buildUrl(path: string, query?: Record<string, unknown>): string {
  const suffix = path.startsWith("/") ? path : `/${path}`;
  const url = `${API_BASE}${suffix}`;
  if (!query) return url;

  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value)) {
      for (const item of value) search.append(key, String(item));
      continue;
    }
    search.set(key, String(value));
  }
  const queryString = search.toString();
  return queryString ? `${url}?${queryString}` : url;
}

function contractDetails(error: z.ZodError): Array<Record<string, unknown>> {
  return error.issues.map((issue) => ({
    path: issue.path.join("."),
    code: issue.code,
    message: issue.message,
  }));
}

function linkedAbortController(signal?: AbortSignal): {
  controller: AbortController;
  detach: () => void;
} {
  const controller = new AbortController();
  const forwardAbort = () => controller.abort(signal?.reason);
  if (signal?.aborted) forwardAbort();
  else signal?.addEventListener("abort", forwardAbort, { once: true });
  return {
    controller,
    detach: () => signal?.removeEventListener("abort", forwardAbort),
  };
}

async function parseError(response: Response, url: string): Promise<ApiError> {
  let payload: unknown;
  try {
    payload = await response.json();
  } catch {
    payload = undefined;
  }

  const parsed = apiErrorEnvelopeSchema.safeParse(payload);
  const envelope = parsed.success ? parsed.data : undefined;
  const backend = envelope?.error;
  const message = backend?.message ?? envelope?.message ?? `Request failed (${response.status})`;
  const metadata = {
    code: backend?.code,
    requestId: backend?.requestId ?? response.headers.get("x-request-id") ?? undefined,
    timestamp: backend?.timestamp,
    details: backend?.details,
  };

  if (response.status === 404) return new ApiNotFoundError(url, metadata);
  return new ApiError(message, response.status, url, metadata);
}

async function request<T>(
  path: string,
  schema: z.ZodType<T>,
  opts: { query?: Record<string, unknown>; signal?: AbortSignal } = {},
): Promise<T> {
  const url = buildUrl(path, opts.query);
  const cached = etagCache.get(url);
  const { controller, detach } = linkedAbortController(opts.signal);
  let timedOut = false;
  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort(new Error("Hidden Grain API request timeout"));
  }, API_REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        ...(cached ? { "If-None-Match": cached.etag } : {}),
      },
      signal: controller.signal,
    });

    if (response.status === 304 && cached) return cached.value as T;
    if (!response.ok) throw await parseError(response, url);

    let payload: unknown;
    try {
      payload = await response.json();
    } catch (cause) {
      throw new ApiContractError(url, [{ path: "", code: "invalid_json", message: "Response is not valid JSON" }], cause);
    }

    const parsed = schema.safeParse(payload);
    if (!parsed.success) {
      throw new ApiContractError(url, contractDetails(parsed.error), parsed.error);
    }

    const etag = response.headers.get("etag");
    if (etag) etagCache.set(url, { etag, value: parsed.data });
    return parsed.data;
  } catch (cause) {
    if (cause instanceof ApiError) throw cause;
    if (timedOut) throw new ApiTimeoutError(url, API_REQUEST_TIMEOUT_MS, cause);
    if (opts.signal?.aborted) throw cause;
    throw new ApiNetworkError(url, cause);
  } finally {
    clearTimeout(timeout);
    detach();
  }
}

export const api = {
  health: (signal?: AbortSignal) => request("/health", healthResponseSchema, { signal }),

  listObjects: (params: ObjectsQueryParams = {}, signal?: AbortSignal) =>
    request("/objects", objectsListResponseSchema, {
      query: params as Record<string, unknown>,
      signal,
    }),

  getObject: (id: string, signal?: AbortSignal) =>
    request(`/objects/${encodeURIComponent(id)}`, objectDetailResponseSchema, { signal }),

  graph: (signal?: AbortSignal) => request("/graph", graphResponseSchema, { signal }),

  clearCache: () => etagCache.clear(),
};

export type Api = typeof api;
