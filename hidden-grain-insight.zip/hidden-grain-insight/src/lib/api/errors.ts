// Error taxonomy for the Hidden Grain API client.
// Structured API metadata is preserved so production incidents can be traced
// with the backend request id. Only transient failures are retried.

export class ApiError extends Error {
  readonly status: number;
  readonly url: string;
  readonly code?: string;
  readonly requestId?: string;
  readonly timestamp?: string;
  readonly details: Array<Record<string, unknown>>;

  constructor(
    message: string,
    status: number,
    url: string,
    metadata: {
      code?: string;
      requestId?: string;
      timestamp?: string;
      details?: Array<Record<string, unknown>>;
      cause?: unknown;
    } = {},
  ) {
    super(message, metadata.cause === undefined ? undefined : { cause: metadata.cause });
    this.name = "ApiError";
    this.status = status;
    this.url = url;
    this.code = metadata.code;
    this.requestId = metadata.requestId;
    this.timestamp = metadata.timestamp;
    this.details = metadata.details ?? [];
  }
}

export class ApiNotFoundError extends ApiError {
  constructor(url: string, metadata: ConstructorParameters<typeof ApiError>[3] = {}) {
    super("Resource not found", 404, url, metadata);
    this.name = "ApiNotFoundError";
  }
}

export class ApiNetworkError extends ApiError {
  constructor(url: string, cause?: unknown) {
    super("Network error while contacting the API", 0, url, {
      code: "NETWORK_ERROR",
      cause,
    });
    this.name = "ApiNetworkError";
  }
}

export class ApiTimeoutError extends ApiError {
  constructor(url: string, timeoutMs: number, cause?: unknown) {
    super(`The API request exceeded ${timeoutMs} ms`, 0, url, {
      code: "REQUEST_TIMEOUT",
      cause,
    });
    this.name = "ApiTimeoutError";
  }
}

export class ApiContractError extends ApiError {
  constructor(url: string, details: Array<Record<string, unknown>>, cause?: unknown) {
    super("The API response does not match the Hidden Grain contract", 502, url, {
      code: "INVALID_API_RESPONSE",
      details,
      cause,
    });
    this.name = "ApiContractError";
  }
}

export function isTransient(err: unknown): boolean {
  if (err instanceof ApiNetworkError || err instanceof ApiTimeoutError) return true;
  if (err instanceof ApiError) return err.status >= 500;
  return false;
}
