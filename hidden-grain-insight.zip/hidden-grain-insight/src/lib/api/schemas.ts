import { z } from "zod";

export const graphNodeSchema = z.object({
  id: z.string().min(1),
  title: z.string(),
  type: z.string(),
  category: z.string(),
});

export const graphEdgeSchema = z.object({
  id: z.string().min(1),
  source: z.string().min(1),
  target: z.string().min(1),
  type: z.string(),
  description: z.string().optional(),
  resolved: z.boolean(),
});

export const knowledgeObjectSummarySchema = z.object({
  id: z.string().min(1),
  title: z.string(),
  type: z.string(),
  category: z.string(),
  status: z.string(),
  version: z.string(),
  summary: z.string(),
  keywords: z.array(z.string()),
  tags: z.array(z.string()),
  path: z.string(),
  checksum: z.string(),
  relationshipCount: z.number().int().nonnegative(),
});

export const objectsListResponseSchema = z.object({
  total: z.number().int().nonnegative(),
  offset: z.number().int().nonnegative(),
  limit: z.number().int().positive(),
  items: z.array(knowledgeObjectSummarySchema),
});

export const objectDetailResponseSchema = z.object({
  object: knowledgeObjectSummarySchema,
  node: graphNodeSchema.optional(),
  relationships: z.object({
    outgoing: z.array(graphEdgeSchema),
    incoming: z.array(graphEdgeSchema),
  }),
});

export const graphResponseSchema = z.object({
  generatedAt: z.string(),
  schemaVersion: z.string(),
  nodeCount: z.number().int().nonnegative(),
  edgeCount: z.number().int().nonnegative(),
  unresolvedEdgeCount: z.number().int().nonnegative(),
  nodes: z.array(graphNodeSchema),
  edges: z.array(graphEdgeSchema),
});

export const healthResponseSchema = z.object({
  status: z.string(),
  service: z.string(),
  schemaVersion: z.string(),
  objects: z.number().int().nonnegative(),
  nodes: z.number().int().nonnegative(),
  edges: z.number().int().nonnegative(),
  generatedAt: z.string(),
});

export const apiErrorEnvelopeSchema = z
  .object({
    error: z
      .object({
        code: z.string().optional(),
        message: z.string().optional(),
        status: z.number().optional(),
        requestId: z.string().optional(),
        timestamp: z.string().optional(),
        details: z.array(z.record(z.unknown())).optional(),
      })
      .optional(),
    message: z.string().optional(),
  })
  .passthrough();
